import processing.core.PApplet;

public class Sketch extends PApplet {

  float[] flakeY = new float[50];
  int[] x = new int[25];
  int[] y = new int[25];
  float[] pileY = new float[50];

public void settings() {
  size(400, 400);
  for (int i = 0; i < flakeY.length; i++) {
    flakeY[i] = random(height);
  }

}

public void draw() {
  background(0);

    x[24] = mouseX;
    y[24] = mouseY;

  stroke(255, 255, 150); // creates yellow snowcubes
  fill(255, 255, 150); 
  for (int j = 0; j < 25 - 1; j++) {
    x[j] = x[j + 1];
    y[j] = y[j + 1];
    rect(x[j], y[j], j + 1, j + 1);
  }

  fill(255, 255, 150); //creates yellow snowflake squares
  for (int i = 0; i < flakeY.length; i++) {
    float flakeX = width * i / flakeY.length;
    rect(flakeX, flakeY[i], 5, 5);

    flakeY[i]++;

    if (flakeY[i] == 400) {
      translate(width, 400);
      ellipse(flakeX, pileY[i] - 1, 8, 8); //creates piles of yellow snow
      }

    if (flakeY[i] > height) { //resets the yellow snowflakes squares
      flakeY[i] = 0;
    
      }
      
    }

  }


}